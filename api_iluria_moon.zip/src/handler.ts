import { Application, Request, Response } from 'express';
import { readdirSync } from 'fs';
import timeout from 'connect-timeout';

import cors from 'cors';
import express from 'express';

export default async function (app: Application) {
    require('../src/utils/bot_events');
    const routes = readdirSync(`${__dirname}/routes`);
    console.log(`[Casey API] Loaded ${routes?.length} routes.`);

    // app.use(timeout('10s'));
    app.use(cors({
        origin: '*',
        methods: ['GET', 'POST']
    }));

    app.use(express.json({ limit: '100mb'}));

    for (const route of routes) {
        const { default: { method, name, execute } } = await import(`./routes/${route}`);
        app[method as keyof Application](name, (req: Request, res: Response) => execute(req, res));
    };
};