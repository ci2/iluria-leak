declare global {
    namespace NodeJS {
        interface ProcessEnv {
            GUILD_ID: string;
            CHANNEL_ID: string;
            AVATAR_URL: string;
            BOT_TOKEN: string;
            PASSWORD: string;
        }
    }
};

export {};