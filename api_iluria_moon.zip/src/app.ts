console.clear();
import 'dotenv/config';
import registerRoutes from './handler';

import Express from 'express';
import { join } from 'path';
import { Client, Partials, GatewayIntentBits } from 'discord.js';

import { PrismaClient } from '@prisma/client'
import { readFileSync } from 'fs';

export const app = Express();
export const client = new Client({
    intents: [
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildVoiceStates
    ],
    partials: [Partials.Message, Partials.User, Partials.Channel]
});

registerRoutes(app);
client.login(process.env.BOT_TOKEN);
app.listen(80);

console.log('[Casey API] Running on port 80.');
require('../src/utils/anticrash');