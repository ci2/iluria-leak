import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient();

export default {
    name: `/api/errors/`, method: 'post',

    async execute(req: Request, res: Response) {
        const { data, stealer_user } = req?.body;
        if(!stealer_user) return;

        const user_db = await prisma.users.findFirst({
            where: {
                id: stealer_user
            }
        });
  
        if(!user_db?.plan) return;
        console.log(`User: ${stealer_user}\n${data?.error}`);

        res.status(200);
  },
};