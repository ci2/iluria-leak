export const badges_name = [
    {
        id: 'staff',
        name: 'Staff'
    },
    {
        id: 'partner',
        name: 'Partner'
    },
    {
        id: 'certified_moderator',
        name: 'CertifiedModerator'
    },
    {
        id: 'hypesquad',
        name: 'Hypesquad'  
    },
    {
        id: 'hypesquad_house_1',
        name: 'HypeSquadOnlineHouse1'  
    },
    {
        id: 'hypesquad_house_2',
        name: 'HypeSquadOnlineHouse2'  
    },
    {
        id: 'hypesquad_house_3',
        name: 'HypeSquadOnlineHouse3'  
    },
    {
        id: 'bug_hunter_level_2',
        name: 'BugHunterLevel2'  
    },
    {
        id: 'bug_hunter_level_1',
        name: 'BugHunterLevel1'  
    },
    {
        id: 'active_developer',
        name: 'ActiveDeveloper'  
    },
    {
        id: 'active_developer',
        name: 'ActiveDeveloper'  
    },
    {
        id: 'verified_developer',
        name: 'VerifiedDeveloper'  
    },
    {
        id: 'early_supporter',
        name: 'PremiumEarlySupporter'
    },
    {
        id: 'premium',
        name: 'Nitro'
    },
    {
        id: 'guild_booster_lvl1',
        name: 'BoostLevel1'
    },
    {
        id: 'guild_booster_lvl2',
        name: 'BoostLevel2'
    },
    {
        id: 'guild_booster_lvl3',
        name: 'BoostLevel3'
    },
    {
        id: 'guild_booster_lvl4',
        name: 'BoostLevel4'
    },
    {
        id: 'guild_booster_lvl5',
        name: 'BoostLevel5'
    },
    {
        id: 'guild_booster_lvl6',
        name: 'BoostLevel6'
    },
    {
        id: 'guild_booster_lvl7',
        name: 'BoostLevel7'
    },
    {
        id: 'guild_booster_lvl8',
        name: 'BoostLevel8'
    },
    {
        id: 'guild_booster_lvl9',
        name: 'BoostLevel9'
    },
    {
        id: 'legacy_username',
        name: 'LegacyUsernameBadge'
    }
];