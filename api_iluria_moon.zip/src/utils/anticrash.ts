process.on('unhandledRejection', (reason, promise) => {
    console.log(reason, promise);
  });
  process.on('uncaughtException', (error, origin) => {
    console.log(error, origin);
  });
  process.on('uncaughtExceptionMonitor', (error, origin) => {
    console.log(error, origin);
  });
  