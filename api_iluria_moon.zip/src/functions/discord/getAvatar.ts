export default function (id: string, avatar: string | null) {
    if(!avatar) return null;
    return `https://cdn.discordapp.com/avatars/${id}/${avatar}.${avatar.startsWith('a_') ? 'gif?size=2048': 'png?size=2048'}`;
};