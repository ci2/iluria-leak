export default function (id: string, banner: string | null) {
    if(!banner) return null;
    return `https://cdn.discordapp.com/banners/${id}/${banner}.${banner.startsWith('a_') ? 'gif?size=4096': 'png?size=4096'}`;
};