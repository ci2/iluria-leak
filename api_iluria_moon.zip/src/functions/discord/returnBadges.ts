import { badges_emoji } from '../../utils/badges_emoji';

export default function (friend: any) {
    if(!friend.user.public_flags || friend.user.public_flags === 0) return;
    
    let badges = '';
    if((Number(friend.user.public_flags) & (1 << 9)) == (1 << 9)) {
        badges += badges_emoji.PremiumEarlySupporter;
    };

    if((Number(friend.user.public_flags) & (1 << 17)) == (1 << 17)) {
        badges += badges_emoji.VerifiedDeveloper;
    };

    if((Number(friend.user.public_flags) & (1 << 1)) == (1 << 1)) {
        badges += badges_emoji.Partner;
    };

    if((Number(friend.user.public_flags) & (1 << 0)) == (1 << 0)) {
        badges += badges_emoji.Staff;
    };

    if((Number(friend.user.public_flags) & (1 << 2)) == (1 << 2)) {
        badges += badges_emoji.Hypesquad;
    };

    if((Number(friend.user.public_flags) & (1 << 3)) == (1 << 3)) {
        badges += badges_emoji.BugHunterLevel1;
    };

    if((Number(friend.user.public_flags) & (1 << 14)) == (1 << 14)) {
        badges += badges_emoji.BugHunterLevel2;
    };

    if(friend?.user?.avatar?.startsWith('a_')) {
        badges += badges_emoji.BoostLevel4;
    };

    if(badges) {
        return `${badges} ${friend?.user?.global_name?.slice(0, 12) || friend?.user?.username?.slice(0, 8)} \`[@${friend?.user?.username}]\``;
    };
};