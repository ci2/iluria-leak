import { Client, Collection, GatewayIntentBits, Partials } from "discord.js";
import "dotenv/config";
import { registerEvents } from "../handler/register-events";
import { registerCommands } from "../handler/register-commands";

import { CaseyClient } from "../types/bot/client";

const Casey = new Client({
  intents: [
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
  ],
  partials: [Partials.GuildMember, Partials.Message, Partials.User],
}) as CaseyClient;

Casey.commands = new Collection();

registerEvents(Casey);
registerCommands(Casey);

Casey.login(process.env.TOKEN);

export default Casey;

process.on("unhandledRejection", (reason, promise) => {
  console.log(reason, promise);
});
process.on("uncaughtException", (error, origin) => {
  console.log(error, origin);
});
process.on("uncaughtExceptionMonitor", (error, origin) => {
  console.log(error, origin);
});
