import { Client, Collection } from "discord.js";

export interface CaseyClient extends Client {
  commands: Collection<string, any>;
}
