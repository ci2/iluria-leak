interface GofileResponse<T> {
  status: string;
  data: T;
}

export async function getServer() {
  const request = await fetch("https://api.gofile.io/getServer");

  const response: GofileResponse<{ server: string }> = await request.json();

  if (response.status !== "ok") throw new Error("Failed to get server");

  return response.data;
}

interface UploadFileResponse {
  downloadPage: string;
  code: string;
  parentFolder: string;
  fileId: string;
  fileName: string;
  md5: string;
}

export async function uploadFile(server: string, file: Buffer, name: string) {
  const blob = new Blob([file], { type: "application/octet-stream" });

  const formData = new FormData();
  formData.append("file", blob, name);

  const request = await fetch(`https://${server}.gofile.io/uploadFile`, {
    method: "POST",
    body: formData,
  });

  const response: GofileResponse<UploadFileResponse> = await request.json();

  if (response.status !== "ok") throw new Error("Failed to upload file");

  return response.data;
}
