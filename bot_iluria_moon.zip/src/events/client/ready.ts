import { Events, ActivityType, SlashCommandBuilder } from "discord.js";
import "colors";
import { CaseyClient } from "../../types/bot/client";

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export default {
  name: Events.ClientReady,
  once: false,

  async execute(client: CaseyClient) {
    const users = await prisma.users.deleteMany({
    where: {
      plan_expiration: {
        lte: Date.now()
      }
    }
  });

  console.log(users);

    // @ts-ignore
    await client.application?.commands.set(client.commands);

    client.user?.setStatus("idle");
    client.user?.setActivity({
      name: "Moon Stealer",
      type: ActivityType.Custom,
    });

    console.log("[Casey Bot] Logged on.");
  },
  
};
