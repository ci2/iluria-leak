import { readdirSync } from "fs";
import { CaseyClient } from "../types/bot/client";

export async function registerCommands(client: CaseyClient) {
  for (const category of readdirSync("./src/commands")) {
    readdirSync("./src/commands/" + category).forEach(async (file) => {
      const { default: command } = await import(
        `../commands/${category}/${file}`
      );

      if (command.name) {
        client.commands.set(command.name, command);
      }
    });
  }
}
