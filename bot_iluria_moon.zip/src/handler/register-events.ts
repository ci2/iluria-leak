import { Client } from "discord.js";
import { readdirSync } from "fs";

export async function registerEvents(client: Client) {
  for (const type of readdirSync("./src/events")) {
    readdirSync(`./src/events/` + type).forEach(async (file) => {
      const { default: event } = await import(`../events/${type}/${file}`);

      if (event.once) {
        client.once(event.name, (...params) => event.execute(...params));
      } else {
        client.on(event.name, (...params) => event.execute(...params));
      }
    });
  }
}
