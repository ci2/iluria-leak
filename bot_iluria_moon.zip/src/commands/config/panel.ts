import {
  EmbedBuilder,
  hyperlink,
  ApplicationCommandOptionType,
  CommandInteraction,
  ActionRowBuilder,
  ChannelSelectMenuBuilder,
  ChannelType,
  ComponentType,
} from "discord.js";
import { CaseyClient } from "../../types/bot/client.js";
import { PrismaClient } from "@prisma/client";
import { emojis } from "../../utils/emojis";

const prisma = new PrismaClient();

export default {
  name: "panel",
  description: "View general informations about your Moon use.",

  run: async (client: CaseyClient, interaction: CommandInteraction) => {
    const user = await prisma.users.findFirst({
      where: {
        id: interaction?.user?.id,
      },
    });

    if (!user)
      return interaction.reply({
        ephemeral: true,
        content: `${emojis.empty} **|** No informations found in the database. Please try again later.`,
      });

    if (!user.plan)
      return interaction.reply({
        ephemeral: true,
        content: `${emojis.empty} **|** You don't have any Moon plan. Buy it in our Telegram.`,
      });

    const plan_embed = new EmbedBuilder()
      .setColor(6212572)
      .setAuthor({
        name: `Moon | Panel`,
        iconURL: interaction.user.avatarURL()!,
      })
      .setFooter({ text: `Moon Stealer`, iconURL: client.user?.avatarURL()! })
      .setTimestamp()
      .setThumbnail(interaction.user.avatarURL())
      .setFields(
        {
          name: `${emojis.badges} Plan:`,
          value: `${user.plan || "Unknown"}`,
          inline: true,
        },
        {
          name: `${emojis.uptime} Expiration:`,
          value: `<t:${~~(
            Math.round(user.plan_expiration!) / 1000
          )}:R> **(<t:${~~(Math.round(user.plan_expiration!) / 1000)}:D>)**`,
          inline: true,
        },
        {
          name: `${emojis.email} Logs Channel:`,
          value: `${
            client.guilds.cache
              .get(user.guild_id!)
              ?.channels.cache.get(user.channel_id!)
              ? client.guilds.cache
                  .get(user.guild_id!)
                  ?.channels.cache.get(user.channel_id!)?.url
              : "Unknown."
          }`,
          inline: false,
        }
      );

    const message = await interaction.reply({
      embeds: [plan_embed],
      components: [
        new ActionRowBuilder<ChannelSelectMenuBuilder>().addComponents(
          new ChannelSelectMenuBuilder()
            .addChannelTypes([ChannelType.GuildText])
            .setCustomId("configLogsChannel")
            .setPlaceholder("Select the logs channel clicking here.")
        ),
      ],
    });

    message
      .createMessageComponentCollector({
        componentType: ComponentType.ChannelSelect,
        filter: (m) => m.member?.user.id === interaction.user.id,
      })
      .on("collect", async (i) => {
        const channel = await interaction.guild?.channels.fetch(i.values[0]);
        if (!channel) return;

        plan_embed.setFields(
          {
            name: `${emojis.badges} Plan:`,
            value: `${user.plan || "Unknown"}`,
            inline: true,
          },
          {
            name: `${emojis.uptime} Expiration:`,
            value: `<t:${~~(
              Math.round(user.plan_expiration!) / 1000
            )}:R> **(<t:${~~(Math.round(user.plan_expiration!) / 1000)}:D>)**`,
            inline: true,
          },
          {
            name: `${emojis.email} Logs Channel:`,
            value: `${channel ? channel?.url : "Unknown."}`,
            inline: false,
          }
        );

        interaction.editReply({
          embeds: [plan_embed],
        });

        i.reply({
          content: `${emojis.email} **|** Now all your victims logs will be sent on ${channel}.`,
          ephemeral: true,
        });

        const update = await prisma.users.update({
          where: {
            id: interaction?.user?.id,
          },
          data: {
            guild_id: interaction.guild?.id,
            channel_id: channel?.id,
          },
        });
      });
  },
};
