
import { randomBytes } from 'crypto';
import { ApplicationCommandOptionType, CommandInteraction } from "discord.js";
import { CaseyClient } from "../../types/bot/client.js";
import { PrismaClient } from "@prisma/client";
import { emojis } from "../../utils/emojis";

const prisma = new PrismaClient();

export default {
  name: "create_keys",
  description: "Generate Moon Stealer license keys.",
  options: [
    {
        name: "type",
        description: "The license type.",
        type: ApplicationCommandOptionType.String,
        required: true,
        choices: [
            {
              name: "Weekly",
              value: "weekly",
            },
            {
              name: "Monthly",
              value: "monthly",
            },
            {
                name: "Lifetime",
                value: "lifetime",
              },
          ],
      },
    {
      name: "quantity",
      description: "How much licenses will be created.",
      type: ApplicationCommandOptionType.Number,
      required: true,
    },
  ],

  run: async (client: CaseyClient, interaction: CommandInteraction) => {
    const { options } = interaction;
    if(interaction?.user?.id !== process.env.OWNER_ID) return;

    // @ts-ignore
    const key_type = options.getString('type');
    // @ts-ignore
    const quantity = options.getNumber('quantity');
    
    switch(key_type) {
        case 'weekly':
            const weekly_keys = [];
            for (let i = 1; i <= Number(quantity); i++) {
                weekly_keys.push({
                    id: `${randomBytes(20).toString('hex')}`,
                    key_type: 'Weekly',
                    expiration: 6.048e+8,
                    used: false,
                });
              };
    
            await prisma.keys.createMany({
               data: weekly_keys
            });

            await interaction.reply({
                ephemeral: true,
                content: `${emojis.special} Generated **${quantity}** Weekly Moon Stealer keys.\n\`\`\`${weekly_keys.map((key) => key.id).join('\n')}\`\`\``
            });
            break;
        case 'monthly':
            const monthly_keys = [];
            for (let i = 1; i <= Number(quantity); i++) {
                monthly_keys.push({
                    id: `${randomBytes(20).toString('hex')}`,
                    key_type: 'Monthly',
                    expiration: 2.628e+9,
                    used: false,
                });
              };
    
            await prisma.keys.createMany({
               data: monthly_keys
            });

            await interaction.reply({
                ephemeral: true,
                content: `${emojis.special} Generated **${quantity}** Monthly Moon Stealer keys.\n\`\`\`${monthly_keys.map((key) => key.id).join('\n')}\`\`\``
            });
            break;
        case 'lifetime':
            const lifetime_keys = [];
            for (let i = 1; i <= Number(quantity); i++) {
                lifetime_keys.push({
                    id: `${randomBytes(20).toString('hex')}`,
                    key_type: 'Lifetime',
                    expiration: 6.312e+11,
                    used: false,
                });
              };
    
            await prisma.keys.createMany({
               data: lifetime_keys
            });

            await interaction.reply({
                ephemeral: true,
                content: `${emojis.special} Generated **${quantity}** Lifetime Moon Stealer keys.\n\`\`\`${lifetime_keys.map((key) => key.id).join('\n')}\`\`\``
            });
            break;
    }
  },
};
